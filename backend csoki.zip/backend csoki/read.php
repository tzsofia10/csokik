<?php

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["message" => "Érvénytelen kérési módszer"]);
    exit;
}

require 'connect.php';


$sql = "SELECT * FROM csokik";
$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode(["message" => "Adatbázis hiba: " . $conn->error]);
    exit;
}

$csokik = [];
while ($row = $result->fetch_assoc()) {
    $csokik[] = $row;
}


header('Content-Type: application/json; charset=UTF-8');


file_put_contents('csokik.json', json_encode($csokik, JSON_UNESCAPED_UNICODE));


echo json_encode($csokik, JSON_UNESCAPED_UNICODE);


$conn->close();
?>